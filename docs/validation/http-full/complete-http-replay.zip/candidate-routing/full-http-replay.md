
### 01 register

```http
POST http://control.test/api/workers/register HTTP/1.1
Authorization: Bearer join-policy
Content-Type: application/json

{"hostname":"local","instance_id":"http-full","session_id":"full-session"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"heartbeat_seconds":10,"worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06","worker_token":"99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8"}

```

### 02 claim-old-profile

```http
POST http://control.test/api/tasks/claim HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"fingerprint_bundle":"6f267d12bdb5e7f6fc64db8b44c71cdae78b70175dd93a346a9d05405867e84e","fingerprint_bundle_schema":"shen-fingerprint-bundle-v2","request_id":"old-profile","session_id":"full-session","supports_confirmed_stop":true,"supports_http_request_budget":true,"types":["http"],"web_enrichment_profile":"bounded-enrichment-v1","web_evidence_profile":"bounded-passive-v1","web_execution_profile":"","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"task":null}

```

### 03 claim-full-profile

```http
POST http://control.test/api/tasks/claim HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"fingerprint_bundle":"6f267d12bdb5e7f6fc64db8b44c71cdae78b70175dd93a346a9d05405867e84e","fingerprint_bundle_schema":"shen-fingerprint-bundle-v2","request_id":"full-profile","session_id":"full-session","supports_confirmed_stop":true,"supports_http_request_budget":true,"types":["http"],"web_enrichment_profile":"bounded-enrichment-v1","web_evidence_profile":"bounded-passive-v1","web_execution_profile":"web-full-v2","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"task":{"id":"full-task","run_id":"full-run","type":"http","attempt_no":1,"payload":{"endpoints":[{"ip":"192.0.2.99","url":"http://192.0.2.99/start","work_key":"stable-entry"}],"fingerprint_bundle":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","fingerprint_bundle_schema":"shen-fingerprint-bundle-v2","http_progress":{"entry_url":"http://192.0.2.99/start","rules_ref":"full-run:http","selection_profile_hash":"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8","manifest_hash":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","reserved_requests":1024,"reserved_segment":1,"segment_request_limit":1024,"segment_requests_used":0,"segment":1,"max_segments":32,"deadline":"2026-10-18T14:47:06.220809+08:00","max_requests":16384,"requests_used":0,"complete":false},"rules":[],"web_enrichment_profile":"bounded-enrichment-v1","web_execution_profile":"web-full-v2","web_profile":"bounded-passive-v1"},"lease_until":"2026-10-18T06:29:06.230986Z","rate_until":"2026-10-18T06:28:06.230986Z","server_time":"2026-10-18T06:27:06.230986Z","control_generation":1}}

```

### 04 permit

```http
POST http://control.test/api/tasks/full-task/http-permit HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":1,"connect_ip":"192.0.2.99","host":"192.0.2.99","port":80,"request_id":"1","segment":1,"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"granted":true,"server_time":"2026-10-18T14:27:06.25756+08:00","valid_until":"2026-10-18T14:27:06.75756+08:00","rate_rps":10,"cluster_rps":250,"burst":1}

```

### 05 checkpoint

```http
POST http://control.test/api/tasks/full-task/batches HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":1,"batch_seq":0,"items":[{"http_progress":{"entry_url":"http://192.0.2.99/start","rules_ref":"full-run:http","selection_profile_hash":"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8","manifest_hash":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","reserved_requests":1024,"reserved_segment":1,"segment_request_limit":1024,"segment_requests_used":0,"segment":1,"max_segments":32,"deadline":"2026-10-18T14:47:06.220809+08:00","max_requests":2048,"requests_used":1,"completed_rule_ids":["rule-one"],"remaining_rule_ids":["rule-two"],"matches":[{"name":"preserved-positive","engine":"fingers"}],"complete":false},"kind":"http","target":"192.0.2.99","ip":"192.0.2.99","port":80,"protocol":"","url":"http://192.0.2.99/start","status_code":200,"execution_profile":"web-full-v2","work_key":"stable-entry","outcome":"incomplete","coverage":"partial","evidence":"{\"fingerprint\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":1,\"entry_id\":\"stable-entry\",\"segment\":1},\"active\":{\"completed_rule_ids\":[\"rule-one\"],\"remaining_rule_ids\":[\"rule-two\"],\"requests\":0,\"complete\":false},\"protocol\":\"shen-web-v1\",\"id\":\"match\",\"bundle\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"},\"probe\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":1,\"entry_id\":\"stable-entry\",\"segment\":1},\"id\":\"probe\",\"input_url\":\"http://192.0.2.99/start\",\"protocol\":\"shen-web-v1\",\"engine\":\"\",\"profile\":\"web-full-v2\",\"response\":{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"},\"attempts\":[{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"}],\"requests\":1}}"}],"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"accepted":true}

```

### 06 checkpoint

```http
POST http://control.test/api/tasks/full-task/batches HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":1,"batch_seq":0,"items":[{"http_progress":{"entry_url":"http://192.0.2.99/start","rules_ref":"full-run:http","selection_profile_hash":"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8","manifest_hash":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","reserved_requests":1024,"reserved_segment":1,"segment_request_limit":1024,"segment_requests_used":0,"segment":1,"max_segments":32,"deadline":"2026-10-18T14:47:06.220809+08:00","max_requests":2048,"requests_used":1,"completed_rule_ids":["rule-one"],"remaining_rule_ids":["rule-two"],"matches":[{"name":"preserved-positive","engine":"fingers"}],"complete":false},"kind":"http","target":"192.0.2.99","ip":"192.0.2.99","port":80,"protocol":"","url":"http://192.0.2.99/start","status_code":200,"execution_profile":"web-full-v2","work_key":"stable-entry","outcome":"incomplete","coverage":"partial","evidence":"{\"fingerprint\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":1,\"entry_id\":\"stable-entry\",\"segment\":1},\"active\":{\"completed_rule_ids\":[\"rule-one\"],\"remaining_rule_ids\":[\"rule-two\"],\"requests\":0,\"complete\":false},\"protocol\":\"shen-web-v1\",\"id\":\"match\",\"bundle\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"},\"probe\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":1,\"entry_id\":\"stable-entry\",\"segment\":1},\"id\":\"probe\",\"input_url\":\"http://192.0.2.99/start\",\"protocol\":\"shen-web-v1\",\"engine\":\"\",\"profile\":\"web-full-v2\",\"response\":{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"},\"attempts\":[{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"}],\"requests\":1}}"}],"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"accepted":true}

```

### 07 confirmed-stop-for-resume

```http
POST http://control.test/api/tasks/full-task/release HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":1,"reason":"fixture restart","retryable":true,"session_id":"full-session","stopped":true,"worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"released":true}

```

### 08 claim-resume

```http
POST http://control.test/api/tasks/claim HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"fingerprint_bundle":"6f267d12bdb5e7f6fc64db8b44c71cdae78b70175dd93a346a9d05405867e84e","fingerprint_bundle_schema":"shen-fingerprint-bundle-v2","request_id":"resume","session_id":"full-session","supports_confirmed_stop":true,"supports_http_request_budget":true,"types":["http"],"web_enrichment_profile":"bounded-enrichment-v1","web_evidence_profile":"bounded-passive-v1","web_execution_profile":"web-full-v2","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"task":{"id":"full-task","run_id":"full-run","type":"http","attempt_no":2,"payload":{"endpoints":[{"ip":"192.0.2.99","url":"http://192.0.2.99/start","work_key":"stable-entry"}],"fingerprint_bundle":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","fingerprint_bundle_schema":"shen-fingerprint-bundle-v2","http_progress":{"entry_url":"http://192.0.2.99/start","rules_ref":"full-run:http","selection_profile_hash":"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8","manifest_hash":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","reserved_requests":2048,"reserved_segment":2,"segment_request_limit":1024,"segment_requests_used":0,"segment":2,"max_segments":32,"deadline":"2026-10-18T14:47:06.220809+08:00","max_requests":2048,"requests_used":1,"completed_rule_ids":["rule-one"],"remaining_rule_ids":["rule-two"],"matches":[{"name":"preserved-positive","engine":"fingers"}],"complete":false},"rules":[],"web_enrichment_profile":"bounded-enrichment-v1","web_execution_profile":"web-full-v2","web_profile":"bounded-passive-v1"},"lease_until":"2026-10-18T06:29:06.286512Z","rate_until":"2026-10-18T06:28:06.286512Z","server_time":"2026-10-18T06:27:06.286512Z","control_generation":1}}

```

### 09 stale-old-attempt

```http
POST http://control.test/api/tasks/full-task/batches HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":1,"batch_seq":1,"items":[{"http_progress":{"entry_url":"http://192.0.2.99/start","rules_ref":"full-run:http","selection_profile_hash":"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8","manifest_hash":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","reserved_requests":1024,"reserved_segment":1,"segment_request_limit":1024,"segment_requests_used":0,"segment":1,"max_segments":32,"deadline":"2026-10-18T14:47:06.220809+08:00","max_requests":2048,"requests_used":1,"completed_rule_ids":["rule-one"],"remaining_rule_ids":["rule-two"],"matches":[{"name":"preserved-positive","engine":"fingers"}],"complete":false},"kind":"http","target":"192.0.2.99","ip":"192.0.2.99","port":80,"protocol":"","url":"http://192.0.2.99/start","status_code":200,"execution_profile":"web-full-v2","work_key":"stable-entry","outcome":"incomplete","coverage":"partial","evidence":"{\"fingerprint\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":2,\"entry_id\":\"stable-entry\",\"segment\":1},\"active\":{\"completed_rule_ids\":[\"rule-one\"],\"remaining_rule_ids\":[\"rule-two\"],\"requests\":0,\"complete\":false},\"protocol\":\"shen-web-v1\",\"id\":\"match\",\"bundle\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"},\"probe\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":2,\"entry_id\":\"stable-entry\",\"segment\":1},\"id\":\"probe\",\"input_url\":\"http://192.0.2.99/start\",\"protocol\":\"shen-web-v1\",\"engine\":\"\",\"profile\":\"web-full-v2\",\"response\":{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"},\"attempts\":[{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"}],\"requests\":1}}"}],"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 409 Conflict
Connection: close
Content-Type: application/json

{"error":"task execution is stale"}

```

### 10 permit

```http
POST http://control.test/api/tasks/full-task/http-permit HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":2,"connect_ip":"192.0.2.99","host":"192.0.2.99","port":80,"request_id":"2","segment":2,"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"granted":true,"server_time":"2026-10-18T14:27:06.413482+08:00","valid_until":"2026-10-18T14:27:06.913482+08:00","rate_rps":10,"cluster_rps":250,"burst":1}

```

### 11 checkpoint

```http
POST http://control.test/api/tasks/full-task/batches HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":2,"batch_seq":0,"items":[{"http_progress":{"entry_url":"http://192.0.2.99/start","rules_ref":"full-run:http","selection_profile_hash":"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8","manifest_hash":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","reserved_requests":1024,"reserved_segment":1,"segment_request_limit":1024,"segment_requests_used":0,"segment":2,"max_segments":32,"deadline":"2026-10-18T14:47:06.220809+08:00","max_requests":2048,"requests_used":2,"completed_rule_ids":["rule-one","rule-two"],"matches":[{"name":"preserved-positive","engine":"fingers"}],"complete":true},"kind":"http","target":"192.0.2.99","ip":"192.0.2.99","port":80,"protocol":"","url":"http://192.0.2.99/start","status_code":200,"execution_profile":"web-full-v2","work_key":"stable-entry","outcome":"identified","coverage":"complete","evidence":"{\"fingerprint\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":2,\"entry_id\":\"stable-entry\",\"segment\":2},\"active\":{\"completed_rule_ids\":[\"rule-one\",\"rule-two\"],\"requests\":0,\"complete\":true},\"protocol\":\"shen-web-v1\",\"id\":\"match\",\"bundle\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"},\"probe\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":2,\"entry_id\":\"stable-entry\",\"segment\":2},\"id\":\"probe\",\"input_url\":\"http://192.0.2.99/start\",\"protocol\":\"shen-web-v1\",\"engine\":\"\",\"profile\":\"web-full-v2\",\"response\":{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"},\"attempts\":[{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"}],\"requests\":1}}"}],"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"accepted":true}

```

### 12 permit

```http
POST http://control.test/api/tasks/full-task/http-permit HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":2,"connect_ip":"192.0.2.99","host":"192.0.2.99","port":80,"request_id":"3","segment":3,"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 409 Conflict
Connection: close
Content-Type: application/json

{"error":"full HTTP cumulative budget, deadline or segment exhausted"}

```

### 13 paused-completion-fenced

```http
POST http://control.test/api/tasks/full-task/complete HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":2,"last_batch_seq":0,"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 409 Conflict
Connection: close
Content-Type: application/json

{"error":"full HTTP run is stopped or paused"}

```

### 14 complete

```http
POST http://control.test/api/tasks/full-task/complete HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":2,"last_batch_seq":0,"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"completed":true,"completion_id":"0d19c45b-3093-41f2-8eac-a49d87fbee47"}

```

### 15 stale-attempt-batch

```http
POST http://control.test/api/tasks/full-task/batches HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":3,"batch_seq":2,"items":[{"http_progress":{"entry_url":"http://192.0.2.99/start","rules_ref":"full-run:http","selection_profile_hash":"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8","manifest_hash":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","reserved_requests":1024,"reserved_segment":1,"segment_request_limit":1024,"segment_requests_used":0,"segment":2,"max_segments":32,"deadline":"2026-10-18T14:47:06.220809+08:00","max_requests":2048,"requests_used":2,"completed_rule_ids":["rule-one","rule-two"],"matches":[{"name":"preserved-positive","engine":"fingers"}],"complete":true},"kind":"http","target":"192.0.2.99","ip":"192.0.2.99","port":80,"protocol":"","url":"http://192.0.2.99/start","status_code":200,"execution_profile":"web-full-v2","work_key":"stable-entry","outcome":"identified","coverage":"complete","evidence":"{\"fingerprint\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":2,\"entry_id\":\"stable-entry\",\"segment\":2},\"active\":{\"completed_rule_ids\":[\"rule-one\",\"rule-two\"],\"requests\":0,\"complete\":true},\"protocol\":\"shen-web-v1\",\"id\":\"match\",\"bundle\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"},\"probe\":{\"execution_profile\":\"web-full-v2\",\"identity\":{\"entry_url\":\"http://192.0.2.99/start\",\"rules_ref\":\"full-run:http\",\"selection_profile_hash\":\"639f10af6104530f9aed519ab78934e13255c97f74a563c2db7e8841919b3ba8\",\"manifest_hash\":\"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\",\"task_id\":\"full-task\",\"attempt_no\":2,\"entry_id\":\"stable-entry\",\"segment\":2},\"id\":\"probe\",\"input_url\":\"http://192.0.2.99/start\",\"protocol\":\"shen-web-v1\",\"engine\":\"\",\"profile\":\"web-full-v2\",\"response\":{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"},\"attempts\":[{\"url\":\"http://192.0.2.99/start\",\"connect_ip\":\"192.0.2.99\",\"host\":\"192.0.2.99\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"request_raw\":\"GET /start HTTP/1.1\\r\\nHost: 192.0.2.99\\r\\n\\r\\n\",\"header_raw\":\"HTTP/1.1 200 OK\\r\\nContent-Length: 2\\r\\n\\r\\n\",\"body\":\"b2s=\",\"body_sha256\":\"2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df\",\"encoded_bytes\":0,\"decoded_bytes\":2,\"completeness\":\"full\"}],\"requests\":1}}"}],"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 409 Conflict
Connection: close
Content-Type: application/json

{"error":"task execution is stale"}

```

### 16 permit

```http
POST http://control.test/api/tasks/full-task/http-permit HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"attempt_no":2,"connect_ip":"192.0.2.99","host":"192.0.2.99","port":80,"request_id":"3","segment":2,"session_id":"full-session","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 409 Conflict
Connection: close
Content-Type: application/json

{"error":"HTTP execution is stale"}

```

### 17 claim-legacy-v1-compatible

```http
POST http://control.test/api/tasks/claim HTTP/1.1
Authorization: Bearer 99a58e79e4022ff9d06e73e4c51bd8b01aacf52c6618ec69748fb9e7ce78f4a8
Content-Type: application/json

{"fingerprint_bundle":"6f267d12bdb5e7f6fc64db8b44c71cdae78b70175dd93a346a9d05405867e84e","fingerprint_bundle_schema":"shen-fingerprint-bundle-v2","request_id":"legacy-v1-compatible","session_id":"full-session","supports_confirmed_stop":true,"supports_http_request_budget":true,"types":["http"],"web_enrichment_profile":"bounded-enrichment-v1","web_evidence_profile":"bounded-passive-v1","web_execution_profile":"web-full-v2","worker_id":"07bb19d3-3bf6-4b16-a029-139a0d9eff06"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"task":{"id":"legacy-task","run_id":"legacy-run","type":"http","attempt_no":1,"payload":{"endpoints":[{"ip":"192.0.2.98","url":"http://192.0.2.98/","work_key":"legacy"}],"web_profile":"bounded-passive-v1","fingerprint_bundle":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","web_enrichment_profile":"bounded-enrichment-v1","fingerprint_bundle_schema":"shen-fingerprint-bundle-v1"},"lease_until":"2026-10-18T06:29:06.475834Z","rate_until":"2026-10-18T06:28:06.475834Z","server_time":"2026-10-18T06:27:06.475834Z","control_generation":1}}

```
