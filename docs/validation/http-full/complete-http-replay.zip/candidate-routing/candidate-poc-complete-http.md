
### register

```http
POST http://control.test/api/workers/register HTTP/1.1
Authorization: Bearer join-policy
Content-Type: application/json

{"hostname":"local","instance_id":"candidate-fixture","session_id":"candidate-session"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"heartbeat_seconds":10,"worker_id":"50597c72-58da-487f-9bf9-7c124c9dc4ed","worker_token":"8e21a17f4e88c2307ea963a845bb7739ec1750a93888f417bda1cfbbdf09b31f"}

```

### candidate-only claim

```http
POST http://control.test/api/tasks/claim HTTP/1.1
Authorization: Bearer 8e21a17f4e88c2307ea963a845bb7739ec1750a93888f417bda1cfbbdf09b31f
Content-Type: application/json

{"request_id":"candidate-only","session_id":"candidate-session","supports_confirmed_stop":true,"supports_http_request_budget":true,"types":["http"],"worker_id":"50597c72-58da-487f-9bf9-7c124c9dc4ed"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"task":{"id":"a13047e1-5bdc-409a-9513-b4fa97ecaf1a","run_id":"0c3e5c1c-92df-4d8c-b426-5e5eaf1e9137","type":"http","attempt_no":1,"payload":{"endpoints":[{"ip":"192.0.2.150","url":"http://192.0.2.150/","work_key":"entry"}],"rules":[]},"lease_until":"2026-10-18T07:00:13.409668Z","rate_until":"2026-10-18T06:59:13.409668Z","server_time":"2026-10-18T06:58:13.409668Z","control_generation":1}}

```

### candidate-only evidence

```http
POST http://control.test/api/tasks/a13047e1-5bdc-409a-9513-b4fa97ecaf1a/batches HTTP/1.1
Authorization: Bearer 8e21a17f4e88c2307ea963a845bb7739ec1750a93888f417bda1cfbbdf09b31f
Content-Type: application/json

{"attempt_no":1,"batch_seq":0,"items":[{"kind":"http","target":"192.0.2.150","ip":"192.0.2.150","port":80,"protocol":"","url":"http://192.0.2.150/","status_code":200,"technologies":[{"candidate":true,"candidate_reason":"bare Goby feature substring","name":"rdp","evidence":"original Goby feature rdp matches WordPress substring","rule_id":"goby:rdp"}],"request_raw":"GET / HTTP/1.1\r\nHost: 192.0.2.150\r\n\r\n","response_raw":"HTTP/1.1 200 OK\r\nContent-Length: 9\r\n\r\nWordPress","work_key":"entry","outcome":"identified","coverage":"complete"}],"session_id":"candidate-session","worker_id":"50597c72-58da-487f-9bf9-7c124c9dc4ed"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"accepted":true}

```

### candidate-only complete

```http
POST http://control.test/api/tasks/a13047e1-5bdc-409a-9513-b4fa97ecaf1a/complete HTTP/1.1
Authorization: Bearer 8e21a17f4e88c2307ea963a845bb7739ec1750a93888f417bda1cfbbdf09b31f
Content-Type: application/json

{"attempt_no":1,"last_batch_seq":0,"session_id":"candidate-session","worker_id":"50597c72-58da-487f-9bf9-7c124c9dc4ed"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"completed":true,"completion_id":"027fd87e-1a42-413d-bea2-1148725198fa"}

```

### independently-confirmed claim

```http
POST http://control.test/api/tasks/claim HTTP/1.1
Authorization: Bearer 8e21a17f4e88c2307ea963a845bb7739ec1750a93888f417bda1cfbbdf09b31f
Content-Type: application/json

{"request_id":"independently-confirmed","session_id":"candidate-session","supports_confirmed_stop":true,"supports_http_request_budget":true,"types":["http"],"worker_id":"50597c72-58da-487f-9bf9-7c124c9dc4ed"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"task":{"id":"db37b969-7848-4f4a-b454-60847971e3ba","run_id":"9cdbb5e0-ef17-4bea-9760-2bcd4192dbfe","type":"http","attempt_no":1,"payload":{"endpoints":[{"ip":"192.0.2.150","url":"http://192.0.2.150/","work_key":"entry"}],"rules":[]},"lease_until":"2026-10-18T07:00:13.482746Z","rate_until":"2026-10-18T06:59:13.482746Z","server_time":"2026-10-18T06:58:13.482746Z","control_generation":1}}

```

### independently-confirmed evidence

```http
POST http://control.test/api/tasks/db37b969-7848-4f4a-b454-60847971e3ba/batches HTTP/1.1
Authorization: Bearer 8e21a17f4e88c2307ea963a845bb7739ec1750a93888f417bda1cfbbdf09b31f
Content-Type: application/json

{"attempt_no":1,"batch_seq":0,"items":[{"kind":"http","target":"192.0.2.150","ip":"192.0.2.150","port":80,"protocol":"","url":"http://192.0.2.150/","status_code":200,"technologies":[{"candidate":true,"candidate_reason":"bare Goby feature substring","name":"rdp","evidence":"original Goby feature rdp matches WordPress substring","rule_id":"goby:rdp"},{"name":"rdp","evidence":"independent complete protocol confirmation","rule_id":"native:rdp-confirmation"}],"request_raw":"GET / HTTP/1.1\r\nHost: 192.0.2.150\r\n\r\n","response_raw":"HTTP/1.1 200 OK\r\nContent-Length: 9\r\n\r\nWordPress","work_key":"entry","outcome":"identified","coverage":"complete"}],"session_id":"candidate-session","worker_id":"50597c72-58da-487f-9bf9-7c124c9dc4ed"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"accepted":true}

```

### independently-confirmed complete

```http
POST http://control.test/api/tasks/db37b969-7848-4f4a-b454-60847971e3ba/complete HTTP/1.1
Authorization: Bearer 8e21a17f4e88c2307ea963a845bb7739ec1750a93888f417bda1cfbbdf09b31f
Content-Type: application/json

{"attempt_no":1,"last_batch_seq":0,"session_id":"candidate-session","worker_id":"50597c72-58da-487f-9bf9-7c124c9dc4ed"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"completed":true,"completion_id":"d2358d56-9a36-4664-8aa9-24314cbb2750"}

```
