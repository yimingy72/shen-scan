# 实际 HTTP 复现数据包

本包不是漏洞利用。包含自建 target 和隔离 Control 的完整请求/响应；.http 保留正文原始字节，JSON 的 response_body_base64 可完整解码。所有令牌均为隔离测试值。

API target http://127.0.0.1:18584，页面 target http://127.0.0.1:19882。运行 fixture.py 可复现测试页面；Control API 请求需在同版本隔离实例上使用对应测试认证和任务 ID。

root-current 为最终修复后的浏览器模式；root-first-modes 含已通过的 collection/passive/active 以及已修复的浏览器 claim 失败；root-before-favicon/root-before-drain 保留问题重现。control 为租约、幂等、鉴权和图片存储 fixture 原始包。
