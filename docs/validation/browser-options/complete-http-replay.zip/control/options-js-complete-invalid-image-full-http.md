
### register

```http
POST http://control.test/api/workers/register HTTP/1.1
Authorization: Bearer join-policy
Content-Type: application/json

{"hostname":"local","instance_id":"options-fixture","session_id":"options"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"heartbeat_seconds":10,"worker_id":"4bfd0695-7b40-459d-9ccf-2342502a0085","worker_token":"8860c3d7d65de196118afdec78e384759ff95b0248d12a78405b058737eee808"}

```

### worker-browser-readiness

```http
POST http://control.test/api/workers/heartbeat HTTP/1.1
Authorization: Bearer 8860c3d7d65de196118afdec78e384759ff95b0248d12a78405b058737eee808
Content-Type: application/json

{"browser_status":{"browser_ready":false,"browser_unavailable_reason":"system Chrome missing"},"metrics":{"browser_cpu_percent":12,"browser_processes":1,"browser_ready":0,"browser_rss_mib":24.5},"session_id":"options","status":"ready","worker_id":"4bfd0695-7b40-459d-9ccf-2342502a0085"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"action":"continue","control_generation":1,"prefer_service":false,"preference_ttl_seconds":20,"reason":"","stop_task_ids":[]}

```

### create-default-options

```http
POST http://control.test/api/runs HTTP/1.1
Authorization: Bearer admin-policy
Content-Type: application/json

{"modes":["http"],"name":"defaults","targets":["http://192.0.2.42/default"]}
HTTP/1.1 201 Created
Connection: close
Content-Type: application/json

{"web_scan_options":{"passive":true,"active":true,"js_dom":false,"screenshot":false},"id":"ddff26aa-5b94-47f1-8933-79f9d86d2ca3","name":"defaults","targets":["http://192.0.2.42/default"],"modes":["http"],"status":"pending","created_at":"2026-10-18T10:17:53.394935Z","updated_at":"2026-10-18T10:17:53.394935Z","task_total":1,"task_done":0,"task_failed":0,"asset_count":0,"target_count":1,"target_done":0,"open_port_count":0,"http_count":0,"input_count":1,"poc_enabled":false,"finding_count":0,"verification_finding_count":0,"check_match_count":0,"discovery_match_count":0,"poc_checked_count":0,"error":""}

```

### create-default-options

```http
POST http://control.test/api/runs HTTP/1.1
Authorization: Bearer admin-policy
Content-Type: application/json

{"modes":["http"],"name":"defaults","targets":["http://192.0.2.42/default"],"web_scan_options":{"passive":false,"active":false,"js_dom":false,"screenshot":false}}
HTTP/1.1 201 Created
Connection: close
Content-Type: application/json

{"web_scan_options":{"passive":false,"active":false,"js_dom":false,"screenshot":false},"id":"eb852fe5-837d-472f-881a-bbe6bc14c3d2","name":"defaults","targets":["http://192.0.2.42/default"],"modes":["http"],"status":"pending","created_at":"2026-10-18T10:17:53.416124Z","updated_at":"2026-10-18T10:17:53.416124Z","task_total":1,"task_done":0,"task_failed":0,"asset_count":0,"target_count":1,"target_done":0,"open_port_count":0,"http_count":0,"input_count":1,"poc_enabled":false,"finding_count":0,"verification_finding_count":0,"check_match_count":0,"discovery_match_count":0,"poc_checked_count":0,"error":""}

```

### old-agent-must-not-ignore-options

```http
POST http://control.test/api/tasks/claim HTTP/1.1
Authorization: Bearer 8860c3d7d65de196118afdec78e384759ff95b0248d12a78405b058737eee808
Content-Type: application/json

{"http_phase":"browser","request_id":"old-agent-must-not-ignore-options","session_id":"options","supports_confirmed_stop":true,"supports_http_request_budget":true,"supports_web_scan_options":false,"types":["http"],"web_browser_profile":"wapp-browser-v1","worker_id":"4bfd0695-7b40-459d-9ccf-2342502a0085"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"task":null}

```

### new-agent-screenshot-child

```http
POST http://control.test/api/tasks/claim HTTP/1.1
Authorization: Bearer 8860c3d7d65de196118afdec78e384759ff95b0248d12a78405b058737eee808
Content-Type: application/json

{"http_phase":"browser","request_id":"new-agent-screenshot-child","session_id":"options","supports_confirmed_stop":true,"supports_http_request_budget":true,"supports_web_scan_options":true,"types":["http"],"web_browser_profile":"wapp-browser-v1","worker_id":"4bfd0695-7b40-459d-9ccf-2342502a0085"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"task":{"id":"4cda0216-5297-4cf6-a888-15a227c2c420","run_id":"options-run","type":"http","attempt_no":1,"payload":{"phase":"browser","endpoints":[{"ip":"192.0.2.42","url":"http://192.0.2.42/","work_key":"fixed-home"}],"browser_sni":"192.0.2.42","browser_url":"http://192.0.2.42/","browser_host":"192.0.2.42","max_requests":32,"browser_parent":{"task_id":"options-parent","identity":{"task_id":"options-parent","entry_id":"fixed-home","entry_url":"http://192.0.2.42/","attempt_no":1},"attempt_no":1,"completion_id":"parent-completion","observation_id":"options-parent-asset","observation_sha256":"55ee93b626a68e305aecd327afd640c23a5d7a687dcd8ae39879e5d7217d561a"},"source_task_id":"options-parent","browser_deadline":"2026-10-18T10:18:23.452031+00:00","web_scan_options":{"active":false,"js_dom":true,"passive":false,"screenshot":true},"source_attempt_no":1,"browser_cff_sha256":"5a88b45afa7ea033a3c251422ecaf7f82e89927a5c72c3c94039ba7af62e62a8","browser_connect_ip":"192.0.2.42","web_browser_profile":"wapp-browser-v1","source_completion_id":"parent-completion","browser_requests_used":0,"browser_js_dom_required":true,"execution_timeout_seconds":20},"lease_until":"2026-10-18T10:19:53.461223Z","rate_until":"2026-10-18T10:18:53.461223Z","server_time":"2026-10-18T10:17:53.461223Z","control_generation":1}}

```

### expired-image-result-fenced

```http
POST http://control.test/api/tasks/4cda0216-5297-4cf6-a888-15a227c2c420/batches HTTP/1.1
Authorization: Bearer 8860c3d7d65de196118afdec78e384759ff95b0248d12a78405b058737eee808
Content-Type: application/json

{"attempt_no":1,"batch_seq":0,"items":[{"kind":"http","target":"192.0.2.42","ip":"192.0.2.42","port":0,"protocol":"","url":"http://192.0.2.42/","evidence":"{\"browser\":{\"js_dom\":{\"state\":\"complete\"},\"screenshot\":{\"state\":\"complete\",\"png\":\"aW52YWxpZCBQTkc=\"},\"id\":\"options-result\",\"protocol\":\"shen-web-v1\",\"profile\":\"wapp-browser-v1\",\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"4cda0216-5297-4cf6-a888-15a227c2c420\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"},\"parent\":{\"task_id\":\"options-parent\",\"attempt_no\":1,\"completion_id\":\"parent-completion\",\"observation_id\":\"options-parent-asset\",\"observation_sha256\":\"55ee93b626a68e305aecd327afd640c23a5d7a687dcd8ae39879e5d7217d561a\",\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"options-parent\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"}},\"cff_sha256\":\"5a88b45afa7ea033a3c251422ecaf7f82e89927a5c72c3c94039ba7af62e62a8\",\"engine\":\"fixture-js+fixture-screenshot\",\"plan_sha256\":\"64879f7d6b960a01909762d911a32d4582c20010c5641ee90278b644a9e3b525\",\"total_rules\":1,\"evaluated_rules\":1,\"unsupported_rules\":0,\"incomplete_rules\":0,\"matches\":[{\"name\":\"JS independent positive\",\"engine\":\"fixture-js\"}],\"requests\":0,\"complete\":false}}"}],"session_id":"options","worker_id":"4bfd0695-7b40-459d-9ccf-2342502a0085"}
HTTP/1.1 409 Conflict
Connection: close
Content-Type: application/json

{"error":"task execution is stale"}

```

### different-parent-image-fenced

```http
POST http://control.test/api/tasks/4cda0216-5297-4cf6-a888-15a227c2c420/batches HTTP/1.1
Authorization: Bearer 8860c3d7d65de196118afdec78e384759ff95b0248d12a78405b058737eee808
Content-Type: application/json

{"attempt_no":1,"batch_seq":0,"items":[{"kind":"http","target":"192.0.2.42","ip":"192.0.2.42","port":0,"protocol":"","url":"http://192.0.2.42/","evidence":"{\"browser\":{\"js_dom\":{\"state\":\"complete\"},\"screenshot\":{\"state\":\"complete\",\"png\":\"aW52YWxpZCBQTkc=\"},\"id\":\"options-result\",\"protocol\":\"shen-web-v1\",\"profile\":\"wapp-browser-v1\",\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"4cda0216-5297-4cf6-a888-15a227c2c420\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"},\"parent\":{\"task_id\":\"options-parent\",\"attempt_no\":1,\"completion_id\":\"parent-completion\",\"observation_id\":\"options-parent-asset\",\"observation_sha256\":\"55ee93b626a68e305aecd327afd640c23a5d7a687dcd8ae39879e5d7217d561a\",\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"options-parent\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"}},\"cff_sha256\":\"5a88b45afa7ea033a3c251422ecaf7f82e89927a5c72c3c94039ba7af62e62a8\",\"engine\":\"fixture-js+fixture-screenshot\",\"plan_sha256\":\"64879f7d6b960a01909762d911a32d4582c20010c5641ee90278b644a9e3b525\",\"total_rules\":1,\"evaluated_rules\":1,\"unsupported_rules\":0,\"incomplete_rules\":0,\"matches\":[{\"name\":\"JS independent positive\",\"engine\":\"fixture-js\"}],\"requests\":0,\"complete\":false}}"}],"session_id":"options","worker_id":"4bfd0695-7b40-459d-9ccf-2342502a0085"}
HTTP/1.1 422 Unprocessable Entity
Connection: close
Content-Type: application/json

{"error":"browser source execution is no longer accepted"}

```

### accept-image-independent-stages

```http
POST http://control.test/api/tasks/4cda0216-5297-4cf6-a888-15a227c2c420/batches HTTP/1.1
Authorization: Bearer 8860c3d7d65de196118afdec78e384759ff95b0248d12a78405b058737eee808
Content-Type: application/json

{"attempt_no":1,"batch_seq":0,"items":[{"kind":"http","target":"192.0.2.42","ip":"192.0.2.42","port":0,"protocol":"","url":"http://192.0.2.42/","evidence":"{\"browser\":{\"js_dom\":{\"state\":\"complete\"},\"screenshot\":{\"state\":\"complete\",\"png\":\"aW52YWxpZCBQTkc=\"},\"id\":\"options-result\",\"protocol\":\"shen-web-v1\",\"profile\":\"wapp-browser-v1\",\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"4cda0216-5297-4cf6-a888-15a227c2c420\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"},\"parent\":{\"task_id\":\"options-parent\",\"attempt_no\":1,\"completion_id\":\"parent-completion\",\"observation_id\":\"options-parent-asset\",\"observation_sha256\":\"55ee93b626a68e305aecd327afd640c23a5d7a687dcd8ae39879e5d7217d561a\",\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"options-parent\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"}},\"cff_sha256\":\"5a88b45afa7ea033a3c251422ecaf7f82e89927a5c72c3c94039ba7af62e62a8\",\"engine\":\"fixture-js+fixture-screenshot\",\"plan_sha256\":\"64879f7d6b960a01909762d911a32d4582c20010c5641ee90278b644a9e3b525\",\"total_rules\":1,\"evaluated_rules\":1,\"unsupported_rules\":0,\"incomplete_rules\":0,\"matches\":[{\"name\":\"JS independent positive\",\"engine\":\"fixture-js\"}],\"requests\":0,\"complete\":false}}"}],"session_id":"options","worker_id":"4bfd0695-7b40-459d-9ccf-2342502a0085"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"accepted":true}

```

### uncompleted-image-not-visible

```http
GET http://control.test/api/observations/5aa3061f-705a-4dd6-8374-c4afe8643434/screenshot HTTP/1.1
Accept-Encoding: gzip
Authorization: Bearer admin-policy
Content-Type: application/json

null
HTTP/1.1 404 Not Found
Connection: close
Content-Type: application/json

{"error":"截图不存在或尚未完成"}

```

### complete-child

```http
POST http://control.test/api/tasks/4cda0216-5297-4cf6-a888-15a227c2c420/complete HTTP/1.1
Authorization: Bearer 8860c3d7d65de196118afdec78e384759ff95b0248d12a78405b058737eee808
Content-Type: application/json

{"attempt_no":1,"last_batch_seq":0,"session_id":"options","worker_id":"4bfd0695-7b40-459d-9ccf-2342502a0085"}
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"completed":true,"completion_id":"692ff70d-be41-4f2f-8677-517f0770a2a8"}

```

### image-requires-auth

```http
GET http://control.test/api/observations/5aa3061f-705a-4dd6-8374-c4afe8643434/screenshot HTTP/1.1
Accept-Encoding: gzip
Content-Type: application/json

null
HTTP/1.1 401 Unauthorized
Connection: close
Content-Type: application/json

{"error":"invalid administrator token"}

```

### invalid-png-not-served

```http
GET http://control.test/api/observations/5aa3061f-705a-4dd6-8374-c4afe8643434/screenshot HTTP/1.1
Accept-Encoding: gzip
Authorization: Bearer admin-policy
Content-Type: application/json

null
HTTP/1.1 404 Not Found
Connection: close
Content-Type: application/json

{"error":"截图不存在或尚未完成"}

```

### detail-no-base64

```http
GET http://control.test/api/observations/5aa3061f-705a-4dd6-8374-c4afe8643434 HTTP/1.1
Authorization: Bearer admin-policy
Content-Type: application/json

null
HTTP/1.1 200 OK
Connection: close
Content-Type: application/json

{"id":"5aa3061f-705a-4dd6-8374-c4afe8643434","run_id":"options-run","observed_at":"2026-10-18T18:17:53.512376+08:00","web_scan_options":{"passive":false,"active":false,"js_dom":true,"screenshot":true},"screenshot":{"state":"partial","error":"screenshot must be a complete PNG","stop_reason":"invalid-screenshot"},"browser":{"js_dom":{"state":"complete"},"profile":"wapp-browser-v1","state":"complete"},"http_progress":{"reserved_requests":0,"reserved_segment":0,"segment_request_limit":0,"segment_requests_used":0,"segment":0,"max_segments":0,"deadline":"0001-01-01T00:00:00Z","max_requests":0,"requests_used":0,"complete":true},"kind":"http","target":"192.0.2.42","ip":"192.0.2.42","port":80,"protocol":"","url":"http://192.0.2.42/","status_code":200,"title":"base remains visible","technologies":[{"name":"JS independent positive","rule_id":"httpx-browser:JS independent positive"}],"work_key":"fixed-home","outcome":"incomplete","coverage":"partial","evidence":"{\"browser\":{\"js_dom_enabled\":true,\"js_dom\":{\"state\":\"complete\"},\"screenshot\":{\"state\":\"partial\",\"error\":\"screenshot must be a complete PNG\",\"stop_reason\":\"invalid-screenshot\"},\"id\":\"options-result\",\"protocol\":\"shen-web-v1\",\"profile\":\"wapp-browser-v1\",\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"4cda0216-5297-4cf6-a888-15a227c2c420\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"},\"parent\":{\"task_id\":\"options-parent\",\"attempt_no\":1,\"completion_id\":\"parent-completion\",\"observation_id\":\"options-parent-asset\",\"observation_sha256\":\"55ee93b626a68e305aecd327afd640c23a5d7a687dcd8ae39879e5d7217d561a\",\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"options-parent\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"}},\"cff_sha256\":\"5a88b45afa7ea033a3c251422ecaf7f82e89927a5c72c3c94039ba7af62e62a8\",\"engine\":\"fixture-js+fixture-screenshot\",\"plan_sha256\":\"64879f7d6b960a01909762d911a32d4582c20010c5641ee90278b644a9e3b525\",\"total_rules\":1,\"evaluated_rules\":1,\"unsupported_rules\":0,\"incomplete_rules\":0,\"matches\":[{\"name\":\"JS independent positive\",\"engine\":\"fixture-js\"}],\"requests\":0,\"complete\":false},\"fingerprint\":{\"identity\":{},\"active\":{\"requests\":0,\"complete\":true},\"protocol\":\"\",\"id\":\"\",\"bundle\":\"\"},\"probe\":{\"identity\":{\"entry_url\":\"http://192.0.2.42/\",\"task_id\":\"options-parent\",\"attempt_no\":1,\"entry_id\":\"fixed-home\"},\"id\":\"\",\"protocol\":\"shen-web-v1\",\"engine\":\"\",\"profile\":\"web-full-v2\",\"response\":{\"url\":\"http://192.0.2.42/\",\"connect_ip\":\"192.0.2.42\",\"host\":\"192.0.2.42\",\"observed_at\":\"0001-01-01T00:00:00Z\",\"status_code\":200,\"headers\":{\"Content-Type\":[\"text/html\"]},\"encoded_bytes\":0,\"decoded_bytes\":0,\"completeness\":\"full\"},\"cff_sha256\":\"5a88b45afa7ea033a3c251422ecaf7f82e89927a5c72c3c94039ba7af62e62a8\",\"requests\":0}}"}

```

### deleted-image-not-served

```http
GET http://control.test/api/observations/5aa3061f-705a-4dd6-8374-c4afe8643434/screenshot HTTP/1.1
Accept-Encoding: gzip
Authorization: Bearer admin-policy
Content-Type: application/json

null
HTTP/1.1 404 Not Found
Connection: close
Content-Type: application/json

{"error":"截图不存在或尚未完成"}

```
