from pathlib import Path
import base64,gzip,http.server,json,threading,time
ROOT=Path(__file__).resolve().parent/'fixture-http';ROOT.mkdir(exist_ok=True)
LOCK=threading.Lock();SEQ=0
HTML=b'''<!doctype html><html><head><meta name="generator" content="WordPress 6.4"><meta name="viewport" content="width=device-width"><title>SHEN Browser Validation</title><link rel="stylesheet" href="/screen.css"><link rel="icon" href="/favicon.ico"></head><body><header><img src="/logo.svg" width="36" height="36"> SHEN / SELF-OWNED TARGET <span>HTTP 200</span></header><main><p class="eyebrow">HTTP FINGERPRINT + SYSTEM CHROME</p><h1>One page. Two browser outputs.</h1><p class="intro">This isolated fixture verifies screenshot rendering and runtime JS / DOM fingerprint evidence.</p><section><article><b>01</b><h2>HTTP collection</h2><p>Headers, title, HTML and favicon.</p></article><article><b>02</b><h2>Runtime evidence</h2><p id="runtime-status">Waiting for JavaScript</p></article><article><b>03</b><h2>Screenshot</h2><p>httpx capture / installed Chrome</p></article></section><footer>Self-owned test fixture / No external services</footer></main><script src="/runtime.js"></script></body></html>'''
CSS=b'''*{box-sizing:border-box}body{margin:0;background:#f3f6fb;color:#19243b;font:16px system-ui,sans-serif}header{height:76px;padding:20px 48px;display:flex;align-items:center;gap:12px;border-bottom:1px solid #dce4ef;background:white;font-weight:650;font-size:14px}header span{margin-left:auto;font-size:12px;color:#18745b;background:#e5f8f0;padding:5px 10px;border-radius:20px}main{padding:44px 48px}.eyebrow{color:#3b61d0;letter-spacing:2px;font-size:12px;font-weight:bold}h1{font-size:42px;letter-spacing:-1.8px;margin:18px 0}p{line-height:1.6}.intro{color:#687a97;max-width:750px}section{display:flex;gap:18px;margin-top:38px}article{flex:1;background:white;border:1px solid #dce4ef;border-radius:12px;padding:24px}article b{color:#5678e4;font-size:28px}h2{font-size:18px}article p{font-size:14px;color:#687a97}footer{margin-top:30px;color:#7c8ca6;font-size:12px}'''
JS=b"window.jQuery={fn:{jquery:'3.7.1'}};window.React={version:'18.2.0'};setTimeout(()=>{const n=document.getElementById('runtime-status');n.textContent='Runtime ready / jQuery 3.7.1';n.setAttribute('data-browser-only','complete');window.SHENFixture={version:'9.4.2'}},80);"
SVG=b'<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="36" height="36" rx="8" fill="#4266d7"/><path d="M9 12h18M9 18h18M9 24h18" stroke="white" stroke-width="3"/></svg>'
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a7o8AAAAASUVORK5CYII=')
class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):self.respond()
 def do_HEAD(self):self.respond()
 def do_POST(self):self.respond()
 def respond(self):
  global SEQ
  request_body=self.rfile.read(int(self.headers.get('Content-Length','0')))
  resources={'/':(HTML,'text/html; charset=utf-8'),'/screen.css':(CSS,'text/css'),'/runtime.js':(JS,'application/javascript'),'/logo.svg':(SVG,'image/svg+xml'),'/favicon.ico':(PNG,'image/png')}
  path=self.path.split('?',1)[0]
  body,typ=resources.get(path,(b'fixture route absent','text/plain'));status=200 if path in resources else 404
  headers=[('Content-Type',typ),('Connection','close')]
  if path=='/runtime.js':body=gzip.compress(body,mtime=0);headers.append(('Content-Encoding','gzip'))
  headers.append(('Content-Length',str(len(body))))
  head=f'HTTP/1.1 {status} {self.responses[status][0]}\r\n'.encode()+b''.join(f'{k}: {v}\r\n'.encode() for k,v in headers)+b'\r\n';payload=b'' if self.command=='HEAD' else body
  try:self.wfile.write(head+payload)
  except (BrokenPipeError,ConnectionResetError):pass
  self.close_connection=True
  with LOCK:
   SEQ+=1;stem=f'{time.time_ns()}-{SEQ:05d}'
   request=self.raw_requestline+b''.join(f'{k}: {v}\r\n'.encode() for k,v in self.headers.items())+b'\r\n'+request_body
   (ROOT/(stem+'.http')).write_bytes(request+b'\r\n'+head+payload)
   (ROOT/(stem+'.json')).write_text(json.dumps({'method':self.command,'url':'http://'+self.headers.get('Host','')+self.path,'request_headers':list(self.headers.items()),'request_body_base64':base64.b64encode(request_body).decode(),'status':status,'response_headers':headers,'response_body_base64':base64.b64encode(payload).decode()},indent=2))
http.server.ThreadingHTTPServer(('127.0.0.1',19882),Handler).serve_forever()
